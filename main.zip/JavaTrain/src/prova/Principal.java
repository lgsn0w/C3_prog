package prova;

import javax.swing.JOptionPane;
import java.io.*;

public class Principal {
    static StringBuffer memoria = new StringBuffer();///Memorizza i dati ricevuti
    static String arquivo = EscolherArquivo.caminho();///Attribuisce il cammino al file

    public static void main(String[] args) {
        do {
            int menu = Integer.parseInt(JOptionPane.showInputDialog(
                    "1- Cadastrar um personagem\n" +
                            "2- Consulta\n" +
                            "3- Alterar dados\n" +
                            "4- Excluir dados\n" +
                            "5- Integrantes do grupo\n" +
                            "6- Mostra geral\n"+
                            "7- Sair"));
            switch (menu) {
                case 1:
                    cadastro();
                    break;
                case 2:
                    consulta();
                    break;
                case 3:
                    alterarDados();
                    break;
                case 4:
                    excluirDados();
                    break;
                case 5:
                    nomes();
                    break;
                case 6:
                    mostraGeral();
                    break;
                case 7:
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Digite uma opção valida");
                    break;
            }
        } while (true);
    }

    static void cadastro() {
        try {
            BufferedWriter saida = new BufferedWriter(new FileWriter(arquivo, true));///Istanzia saida e poi indica di scrivere nel file
            String nome = JOptionPane.showInputDialog("Digite o nome: ").toUpperCase();
            String nomeJogo = JOptionPane.showInputDialog("Digite o nome do jogo de origem: ").toUpperCase();
            String ano = JOptionPane.showInputDialog("Digite o ano de criação: ");
            saida.write(nome + "\t");
            saida.write(nomeJogo + "\t");
            saida.write(ano + "\n");///Scrive i dati
            saida.flush();
            saida.close();///Sciaqua i dati e chiude
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de gravaaco");
        }
    }

    static void consulta() {
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(arquivo));///Istanzia e indica quale file di leggere
            String nome = JOptionPane.showInputDialog("Nome do personagem: ").toUpperCase();
            String nome2;
            while (nome.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Erro, nenhum nome foi escrito");
                nome2 = JOptionPane.showInputDialog("Digite um nome");
                nome = nome2;
            }
            String linha;
            String nomeJogo;
            String ano;
            memoria.delete(0, memoria.length());
            while ((linha = entrada.readLine()) != null) {///Mentre esiste qualcosa nella linea, la salta
                memoria.append(linha).append("\n");
            }
            int inicio = memoria.indexOf(nome);
            if (inicio != -1) {
                int ultimo = memoria.indexOf("\t", inicio);
                nome = ler(inicio, ultimo);
                int primeiro = ultimo + 1;
                ultimo = memoria.indexOf("\t", primeiro);
                nomeJogo = ler(primeiro, ultimo);
                primeiro = ultimo + 1;
                int fim = memoria.indexOf("\n", primeiro);
                ano = ler(primeiro, fim);
                DB dados = new DB(nome, nomeJogo, ano);
                JOptionPane.showMessageDialog(null, dados.getNomeJogo() + "\n" + dados.getAno());
            } else {
                JOptionPane.showMessageDialog(null, "Não cadastrado");
            }
            entrada.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nenhum cadastro");
        }
    }

    static void alterarDados() {
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(arquivo));
            String nome = JOptionPane.showInputDialog("Nome:").toUpperCase();
            String nome2;
            while (nome.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Erro, nenhum nome foi escrito");
                nome2 = JOptionPane.showInputDialog("Digite um nome");
                nome = nome2;
            }
            String linha;
            String nomeJogo;
            String ano;
            memoria.delete(0, memoria.length());
            while ((linha = entrada.readLine()) != null) {
                memoria.append(linha).append("\n");
            }
            int inicio = memoria.indexOf(nome);
            if (inicio != -1) {
                int ultimo = memoria.indexOf("\t", inicio);
                nome = ler(inicio, ultimo);
                int primeiro = ultimo + 1;
                ultimo = memoria.indexOf("\t", primeiro);
                nomeJogo = ler(primeiro, ultimo);
                primeiro = ultimo + 1;
                int fim = memoria.indexOf("\n", primeiro);
                ano = ler(primeiro, fim);
                DB dados = new DB(nome, nomeJogo, ano);
                JOptionPane.showMessageDialog(null, dados.getNome() + "\n" + dados.getNomeJogo() + "\n" + dados.getAno());
                nomeJogo = JOptionPane.showInputDialog("Novo nome do jogo: ").toUpperCase();
                dados.setNomeJogo(nomeJogo);
                ano = JOptionPane.showInputDialog("Novo ano: ").toUpperCase();
                dados.setAno(ano);
                memoria.replace(inicio, fim + 1, dados.toString());///L'aggiunta di tutti i dati precedenti
                gravar();
                JOptionPane.showMessageDialog(null, "Cadastro alterado");
            } else {
                JOptionPane.showMessageDialog(null, "Cadastro não alterado");
            }
            entrada.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro");
        }
    }

    public static void excluirDados() {
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(arquivo));
            String nome = JOptionPane.showInputDialog("Nome: ").toUpperCase();
            String nome2;
            while (nome.isEmpty()) {
                JOptionPane.showMessageDialog(null,"Erro, nenhum nome foi escrito");
                nome2 = JOptionPane.showInputDialog("Digite um nome");
                nome = nome2;
            }
            String linha;
            String nomeJogo;
            String ano;
            memoria.delete(0, memoria.length());
            while ((linha = entrada.readLine()) != null) {
                memoria.append(linha).append("\n");
            }
            int inicio = memoria.indexOf(nome);
            if (inicio != -1) {
                int ultimo = memoria.indexOf("\t", inicio);
                nome = ler(inicio, ultimo);
                int primeiro = ultimo + 1;
                ultimo = memoria.indexOf("\t", primeiro);
                nomeJogo = ler(primeiro, ultimo);
                primeiro = ultimo + 1;
                int fim = memoria.indexOf("\n", primeiro);
                ano = ler(primeiro, fim);
                DB dados = new DB(nome, nomeJogo, ano);
                int resposta = JOptionPane.showConfirmDialog(null, "Deseja excluir?" + "\n" + dados.getNome()
                        + "\n" + dados.getNomeJogo() + "\n" + dados.getAno());
                if (resposta == 0) {
                    memoria.delete(inicio, fim + 1);
                    gravar();
                    JOptionPane.showMessageDialog(null, "Atualizado com sucesso");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Nao cadastrado");
            }
            entrada.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Houve um erro na hora de excluir");
        }
    }

    static void gravar() {
        try {
            BufferedWriter saida = new BufferedWriter(new FileWriter(arquivo));
            saida.write(memoria.toString());///Scrive tutti i dati memorizzati
            saida.flush();
            saida.close();
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro de gravação");
        }
    }

    public static String ler(int primeiro, int ultimo) {
        String dados;
        dados = memoria.substring(primeiro, ultimo);
        return dados;

    }

    static void mostraGeral(){
        String linha;
        memoria.delete(0,memoria.length());
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(arquivo));
            while ((linha = entrada.readLine()) != null) {
                memoria.append(linha).append("\n");
            }
            if(memoria.length()==0){
                JOptionPane.showMessageDialog(null,"Nenhum cadastro");
            }
            System.out.println(memoria.toString());
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Erro");
        }
    }
    static void nomes() {
        System.out.println("Lucas Gabriel\nGuilherme Guimarães");
    }
}