package prova;

public class DB {
    private String nome;
    private String nome_jogo;
    private String ano;

    ///Constructor
    public DB(String nome, String nome_jogo, String ano) {
        this.nome = nome;
        this.nome_jogo = nome_jogo;
        this.ano = ano;
    }
    ///Functions
    public String getNome(){
        return nome;
    }
    public String getNomeJogo(){
        return nome_jogo;
    }
    public String getAno(){
        return ano;
    }

    public void setNomeJogo(String nomeJogo){
        this.nome_jogo = nomeJogo;
    }
    public void setAno(String ano){
        this.ano = ano;
    }
    public void setNome(String nome){
        this.nome = nome;
    }

    @Override
    public String toString() {
        return nome + '\t' + nome_jogo + '\t' + ano + '\n';
    }
}
